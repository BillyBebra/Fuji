<?php 
$db = mysql_connect("localhost","thebinra_koment","QJcfly%2");
mysql_select_db("messages",$db);
mysql_query("SET NAMES utf8");
?>